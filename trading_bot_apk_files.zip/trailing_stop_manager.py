import logging
import time
from decimal import Decimal, ROUND_DOWN
from threading import Thread
import gate_api

# Удаляем импорт функций из основного модуля на уровне модуля
# Импортируем их локально внутри функций где они используются

logger = logging.getLogger('trading-bot')

class TrailingStopManager:
    """Управляет трейлинг-стопом для позиций"""
    
    def __init__(self, gate_io_instance):
        self.gate_io = gate_io_instance
        self.user_id = gate_io_instance.user_id
        self.trailing_threads = {}
        
    def start_monitoring(self, symbol, side):
        """Запускает мониторинг трейлинг-стопа для позиции"""
        thread_key = (self.user_id, symbol, side)
        
        # Проверяем, не запущен ли уже мониторинг для этой позиции
        if thread_key in self.trailing_threads and self.trailing_threads[thread_key].is_alive():
            logger.info(f"Мониторинг трейлинг-стопа уже запущен для {symbol} ({side})")
            return
            
        # Запускаем новый поток для мониторинга
        thread = Thread(
            target=self._monitor_position, 
            args=(symbol, side), 
            daemon=True
        )
        thread.start()
        self.trailing_threads[thread_key] = thread
        logger.info(f"Запущен мониторинг трейлинг-стопа для {symbol} ({side})")
        
    def stop_monitoring(self, symbol, side):
        """Останавливает мониторинг трейлинг-стопа для позиции"""
        thread_key = (self.user_id, symbol, side)
        if thread_key in self.trailing_threads:
            # В реальной реализации нужно добавить механизм остановки потока
            # Пока просто удаляем ссылку на поток
            del self.trailing_threads[thread_key]
            logger.info(f"Остановлен мониторинг трейлинг-стопа для {symbol} ({side})")
            
    def cleanup_threads(self):
        """Очищает завершенные потоки"""
        self.trailing_threads = {
            k: v for k, v in self.trailing_threads.items() 
            if v.is_alive()
        }
        
    def _monitor_position(self, symbol, side):
        """Основной цикл мониторинга позиции"""
        try:
            # Локальный импорт для избежания циклического импорта
            from traiding_bot import get_user_data, get_open_trades_by_symbol_and_side, get_tp_config
            
            # Получаем настройки пользователя
            user_data = get_user_data(self.user_id)
            if not user_data:
                logger.error(f"Не удалось получить настройки для пользователя {self.user_id}")
                return
                
            # Получаем конфигурацию TP/SL
            trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
            if not trades:
                logger.info(f"Позиция {symbol} ({side}) не найдена или уже закрыта")
                return
                
            trade = trades[0]
            timescale = trade['timescale']
            tp_config = get_tp_config(self.user_id, timescale)
            
            # Инициализируем переменные для отслеживания PnL
            highest_pnl = None
            trailing_activated = trade['trailing_active'] == 1
            lowest_pnl = None  # Для отслеживания минимального PnL
            
            # Основной цикл мониторинга
            while True:
                # Проверяем, что позиция все еще открыта
                if not self._is_position_open(symbol, side):
                    logger.info(f"Позиция {symbol} ({side}) закрыта, мониторинг остановлен")
                    break
                    
                # Получаем текущую цену
                current_price = self.gate_io.get_current_price(symbol)
                if current_price is None:
                    logger.error(f"Не удалось получить цену для {symbol}")
                    time.sleep(user_data.get('trailing_interval', 3.0))
                    continue
                    
                # Получаем параметры позиции
                entry_price = trade['average_entry_price'] or trade['price']
                amount = trade['amount']
                
                # Получаем PnL с биржи
                current_pnl, pnl_percentage, margin = self._get_position_pnl(symbol, side)
                
                # Обновляем минимальный и максимальный PnL
                if highest_pnl is None or current_pnl > highest_pnl:
                    highest_pnl = current_pnl
                if lowest_pnl is None or current_pnl < lowest_pnl:
                    lowest_pnl = current_pnl
                
                # Форматированный вывод информации о мониторинге
                separator = "─" * 80
                pnl_emoji = "🟢" if current_pnl >= 0 else "🔴"
                trailing_emoji = "🟢" if trailing_activated else "🔴"
                side_text = "BUY" if side == 'buy' else "SELL"
                
                # Рассчитываем цену активации трейлинга
                trigger_price = entry_price * (
                    1 + tp_config['trigger_profit_percentage'] / 100 if side == 'buy' 
                    else 1 - tp_config['trigger_profit_percentage'] / 100
                )
                
                # Формируем вывод в консоль в точном формате, как запросил пользователь
                monitor_info = (
                    f"{separator}\n"
                    f"📈 {symbol} ({side_text}) - Мониторинг трейлинг-стопа\n"
                    f"💰 Цена: {current_price:.4f} | PnL: {pnl_emoji} {current_pnl:+.2f} USDT ({pnl_percentage:+.2f}%)\n"
                    f"🎯 Трейлинг: {trailing_emoji} | Макс PnL: {highest_pnl:.2f} | Мин PnL: {lowest_pnl:.2f}  "
                    f"Цена активации трейлинга: {trigger_price:.5f} | Трейлинг: {'Активен' if trailing_activated else 'Неактивен (ожидает активации)'}\n"
                    f"⏱️  Интервал: {user_data.get('trailing_interval', 3.0):.1f}s | Стоп: {trade.get('current_stop_price', 0):.4f}\n"
                    f"{separator}"
                )
                
                # Выводим информацию в консоль
                print(monitor_info)
                
                # Проверяем стоп-лосс
                if self._check_stop_loss(current_pnl, pnl_percentage, tp_config['stop_loss_percentage']):
                    self._execute_stop_loss(symbol, side, current_price, current_pnl, margin)
                    break
                    
                # Проверяем активацию трейлинга
                if not trailing_activated:
                    if self._check_trailing_activation(pnl_percentage, tp_config['trigger_profit_percentage']):
                        trailing_activated = True
                        self._activate_trailing(symbol, side, trade['trade_id'])
                        highest_pnl = current_pnl
                else:
                    # Обновляем максимальный PnL
                    if highest_pnl is None or current_pnl > highest_pnl:
                        highest_pnl = current_pnl
                        
                    # Проверяем и обновляем трейлинг-стоп
                    self._update_trailing_stop(
                        symbol, side, trade['trade_id'], 
                        current_pnl, highest_pnl, 
                        tp_config['trailing_percentage'], margin
                    )
                    
                # Обновляем данные о сделке
                trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
                if not trades:
                    break
                trade = trades[0]
                
                time.sleep(user_data.get('trailing_interval', 3.0))
                
        except Exception as e:
            logger.error(f"Ошибка в мониторинге трейлинг-стопа для {symbol} ({side}): {str(e)}")
            
    def _is_position_open(self, symbol, side):
        """Проверяет, открыта ли позиция на бирже"""
        try:
            positions = self.gate_io.futures_api.list_positions(settle='usdt')
            for pos in positions:
                if pos.contract == symbol:
                    if (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell'):
                        return pos.size != 0
            return False
        except Exception as e:
            logger.error(f"Ошибка проверки позиции {symbol} ({side}): {str(e)}")
            return True  # На случай ошибки считаем, что позиция открыта
            
    def _get_position_pnl(self, symbol, side):
        """Получает PnL позиции с биржи"""
        try:
            positions = self.gate_io.futures_api.list_positions(settle='usdt')
            for pos in positions:
                if pos.contract == symbol and (
                        (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                    current_pnl = float(pos.unrealised_pnl)
                    margin = float(pos.margin)
                    pnl_percentage = (current_pnl / margin * 100) if margin > 0 else 0.0
                    return current_pnl, pnl_percentage, margin
            return 0.0, 0.0, 0.0
        except Exception as e:
            logger.error(f"Ошибка получения PnL для {symbol} ({side}): {str(e)}")
            return 0.0, 0.0, 0.0
            
    def _check_stop_loss(self, current_pnl, pnl_percentage, stop_loss_percentage):
        """Проверяет, сработал ли стоп-лосс"""
        return pnl_percentage <= -abs(stop_loss_percentage)
        
    def _check_trailing_activation(self, pnl_percentage, trigger_profit_percentage):
        """Проверяет, пора ли активировать трейлинг"""
        return pnl_percentage >= trigger_profit_percentage
        
    def _activate_trailing(self, symbol, side, trade_id):
        """Активирует трейлинг-стоп"""
        try:
            # Локальный импорт для избежания циклического импорта
            from traiding_bot import update_trade_status, bot, GROUP_CHAT_ID, message_lock, sent_messages
            
            update_trade_status(trade_id, "OPEN", trailing_active=1)
            logger.info(f"Трейлинг активирован для {symbol} ({side})")
            
            # Отправляем уведомление в Telegram
            with message_lock:
                msg_key = (self.user_id, symbol, side, 'trailing_activated', int(time.time() // 60))
                if msg_key not in sent_messages:
                    bot.send_message(
                        GROUP_CHAT_ID, 
                        f"🔄 Трейлинг активирован: {symbol} ({side})"
                    )
                    sent_messages.add(msg_key)
        except Exception as e:
            logger.error(f"Ошибка активации трейлинга для {symbol} ({side}): {str(e)}")
            
    def _update_trailing_stop(self, symbol, side, trade_id, current_pnl, highest_pnl, trailing_percentage, margin):
        """Обновляет уровень трейлинг-стопа"""
        try:
            # Рассчитываем уровень трейлинг-стопа
            stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
            
            # Проверяем, пора ли закрывать позицию
            if current_pnl <= stop_pnl:
                # Получаем текущую цену для закрытия
                current_price = self.gate_io.get_current_price(symbol)
                if current_price:
                    self._execute_trailing_stop(symbol, side, current_price, current_pnl, margin)
                return
                
            # Обновляем уровень трейлинг-стопа в базе (если реализация требует)
            # В данной реализации мы не храним stop_pnl в базе, а рассчитываем его каждый раз
            logger.debug(f"Трейлинг-стоп для {symbol} ({side}): текущий PnL={current_pnl}, стоп PnL={stop_pnl}")
            
        except Exception as e:
            logger.error(f"Ошибка обновления трейлинг-стопа для {symbol} ({side}): {str(e)}")
            
    def _execute_stop_loss(self, symbol, side, current_price, current_pnl, margin):
        """Выполняет закрытие позиции по стоп-лоссу"""
        logger.info(f"Сработал стоп-лосс для {symbol} ({side}), PnL={current_pnl}")
        # Получаем trade_id из базы данных
        from traiding_bot import get_open_trades_by_symbol_and_side
        trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
        if trades:
            trade_id = trades[0]['trade_id']
            self._close_position(symbol, side, current_price, current_pnl, margin, "stop_loss", trade_id)
        else:
            logger.warning(f"Не удалось найти trade_id для {symbol} ({side}) при закрытии по стоп-лоссу")
            self._close_position(symbol, side, current_price, current_pnl, margin, "stop_loss", None)
        
    def _execute_trailing_stop(self, symbol, side, current_price, current_pnl, margin):
        """Выполняет закрытие позиции по трейлинг-стопу"""
        logger.info(f"Сработал трейлинг-стоп для {symbol} ({side}), PnL={current_pnl}")
        # Получаем trade_id из базы данных
        from traiding_bot import get_open_trades_by_symbol_and_side
        trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
        if trades:
            trade_id = trades[0]['trade_id']
            self._close_position(symbol, side, current_price, current_pnl, margin, "trailing_stop", trade_id)
        else:
            logger.warning(f"Не удалось найти trade_id для {symbol} ({side}) при закрытии по трейлинг-стопу")
            self._close_position(symbol, side, current_price, current_pnl, margin, "trailing_stop", None)
        
    def _close_position(self, symbol, side, current_price, current_pnl, margin, reason, trade_id=None):
        """Закрывает позицию и обновляет запись в базе"""
        try:
            # Локальный импорт для избежания циклического импорта
            from traiding_bot import get_open_trades_by_symbol_and_side, get_trade_by_id, update_trade_status, bot, GROUP_CHAT_ID, message_lock, sent_messages
            
            # Получаем размер позиции
            positions = self.gate_io.futures_api.list_positions(settle='usdt')
            position_size = 0
            entry_price = 0
            
            for pos in positions:
                if pos.contract == symbol and (
                        (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                    position_size = abs(pos.size)
                    entry_price = float(pos.entry_price)
                    break
                    
            if position_size == 0:
                logger.info(f"Позиция {symbol} ({side}) уже закрыта")
                return
                
            # Закрываем позицию
            contract = self.gate_io.futures_api.get_futures_contract(settle='usdt', contract=symbol)
            quanto_multiplier = float(contract.quanto_multiplier)
            qty = position_size * quanto_multiplier
            
            # Используем улучшенное закрытие позиции
            order_id, actual_qty = self.gate_io.close_position_enhanced(
                symbol, side, qty, reason=reason
            )
            
            if order_id and actual_qty:
                # Получаем информацию о сделке
                trade = None
                if trade_id:
                    # Используем переданный trade_id
                    trade = get_trade_by_id(trade_id)
                else:
                    # Пытаемся найти сделку по символу и стороне
                    trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
                    if trades:
                        trade = trades[0]
                
                if trade:
                    # Получаем прибыль с биржи
                    total_profit = current_pnl  # Используем рассчитанный PnL
                    total_fees = 0.0  # В упрощенной версии не рассчитываем комиссии
                    
                    update_trade_status(
                        trade['trade_id'], "CLOSED",
                        close_price=current_price,
                        close_order_id=order_id,
                        close_reason=reason,
                        pnl=total_profit,
                        fees=total_fees
                    )
                    
                    # Отправляем уведомление
                    self._send_close_notification(
                        symbol, side, entry_price, current_price, 
                        total_profit, margin, reason
                    )
                else:
                    logger.warning(f"Позиция {symbol} ({side}) не найдена в базе данных при закрытии")
            else:
                logger.error(f"Не удалось закрыть позицию {symbol} ({side}), order_id={order_id}, actual_qty={actual_qty}")
                    
        except Exception as e:
            logger.error(f"Ошибка закрытия позиции {symbol} ({side}): {str(e)}")
            
    def _send_close_notification(self, symbol, side, entry_price, current_price, profit, margin, reason):
        """Отправляет уведомление о закрытии позиции"""
        try:
            # Локальный импорт для избежания циклического импорта
            from traiding_bot import bot, GROUP_CHAT_ID, message_lock, sent_messages
            
            profit_percentage = (profit / margin * 100) if margin > 0 else 0.0
            profit_label = "Прибыль" if profit >= 0 else "Убыток"
            side_emoji = "📈" if side == 'buy' else "📉"
            pnl_emoji = "🟢" if profit >= 0 else "🔴"
            
            current_balance = self.gate_io.get_balance_usdt() or 0.0
            
            # Рассчитываем процент прибыли/убытка от баланса
            balance_percentage = (profit / current_balance * 100) if current_balance > 0 else 0.0
            
            # Форматируем причину закрытия на русском языке
            reason_text = {
                "stop_loss": "стоп-лосс",
                "trailing_stop": "трейлинг-стоп",
                "manual": "вручную",
                "reverse_signal": "обратный сигнал"
            }.get(reason, reason.replace('_', ' '))
            
            msg = (
                f"✅ Закрыта {side}: {symbol}\n"
                f"📋 Причина: {reason_text}\n"
                f"💰 {profit_label}: {profit:+.2f} USDT ({profit_percentage:+.2f}%, {balance_percentage:+.2f}% от баланса)\n"
                f"💳 Баланс: {current_balance:.2f} USDT"
            )
            
            with message_lock:
                msg_key = (self.user_id, symbol, side, f'close_{reason}', int(time.time() // 60))
                if msg_key not in sent_messages:
                    bot.send_message(GROUP_CHAT_ID, msg)
                    sent_messages.add(msg_key)
                    
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления о закрытии {symbol} ({side}): {str(e)}")