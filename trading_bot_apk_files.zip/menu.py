#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import subprocess
import json
import sqlite3
from datetime import datetime
import gate_api
from gate_api.exceptions import ApiException

def clear_screen():
    """Очистка экрана"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """Вывод заставки"""
    clear_screen()
    header = r'''
    
        ██████╗  █████╗ ████████╗███████╗
       ██╔════╝ ██╔══██╗╚══██╔══╝██╔════╝
       ██║  ███╗███████║   ██║   █████╗  
       ██║   ██║██╔══██║   ██║   ██╔══╝  
       ╚██████╔╝██║  ██║   ██║   ███████╗
        ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝
                                       
       ██████╗  ██████╗ ████████╗
       ██╔══██╗██╔═══██╗╚══██╔══╝
       ██████╔╝██║   ██║   ██║   
       ██╔══██╗██║   ██║   ██║   
       ██████╔╝╚██████╔╝   ██║   
       ╚═════╝  ╚═════╝    ╚═╝   
                              
'''
    print(header)
    print("=" * 80)
    print(f"{'Добро пожаловать в Gate Bot':^80}")
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S'):^80}")
    print("=" * 80)
    print()

def check_database():
    """Проверка наличия и валидности базы данных"""
    if not os.path.exists('trading_bot.db'):
        print("❌ База данных не найдена!")
        return False
    
    try:
        conn = sqlite3.connect('trading_bot.db')
        cursor = conn.cursor()
        # Проверяем наличие таблиц
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cursor.fetchone():
            print("❌ Таблица users не найдена в базе данных!")
            conn.close()
            return False
        
        # Проверяем наличие хотя бы одного пользователя
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        if count == 0:
            print("❌ В базе данных нет пользователей!")
            conn.close()
            return False
            
        # Проверяем API ключи первого пользователя
        cursor.execute("SELECT api_key, api_secret, account_type FROM users LIMIT 1")
        row = cursor.fetchone()
        if row:
            api_key, api_secret, account_type = row
            # Для демо счета API ключи не обязательны
            if account_type == 'demo':
                conn.close()
                return True
                
            # Для реального счета проверяем API ключи
            if not api_key or not api_secret:
                print("❌ API ключи не установлены!")
                conn.close()
                return False
                
            # Проверяем валидность API ключей
            if not validate_api_keys(api_key, api_secret):
                print("❌ API ключи недействительны!")
                conn.close()
                return False
        
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Ошибка проверки базы данных: {e}")
        return False

def validate_api_keys(api_key, api_secret, account_type='real'):
    """Проверка валидности API ключей"""
    try:
        # Используем правильный URL в зависимости от типа счета
        api_url = "https://api.gateio.ws/api/v4" if account_type == 'real' else "https://api-testnet.gateapi.io/api/v4"
        
        configuration = gate_api.Configuration(
            host=api_url,
            key=api_key,
            secret=api_secret
        )
        api_client = gate_api.ApiClient(configuration)
        futures_api = gate_api.FuturesApi(api_client)
        
        # Пробуем получить информацию о аккаунте
        futures_api.list_futures_accounts(settle='usdt')
        return True
    except ApiException as e:
        print(f"❌ Ошибка проверки API ключей: {e}")
        return False
    except Exception as e:
        print(f"❌ Ошибка проверки API ключей: {e}")
        return False

def setup_database():
    """Создание базы данных и таблиц при их отсутствии"""
    try:
        conn = sqlite3.connect('trading_bot.db')
        cursor = conn.cursor()
        
        # Создание таблицы users
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users
            (
                user_id INTEGER PRIMARY KEY,
                api_key TEXT,
                api_secret TEXT,
                account_type TEXT DEFAULT 'demo',
                leverage REAL DEFAULT 10.0,
                margin_mode TEXT DEFAULT 'isolated',
                order_type TEXT DEFAULT 'percentage',
                qty_percentage REAL DEFAULT 5.0,
                fixed_volume REAL DEFAULT 100.0,
                initial_stop_percentage REAL DEFAULT 3.0,
                trigger_profit_percentage REAL DEFAULT 5.0,
                profit_lock_percentage REAL DEFAULT 2.0,
                trailing_percentage REAL DEFAULT 1.0,
                trailing_interval REAL DEFAULT 3.0,
                daily_loss_limit INTEGER DEFAULT 3,
                max_open_trades INTEGER DEFAULT 5,
                is_trading INTEGER DEFAULT 0,
                report_type TEXT DEFAULT 'fixed',
                report_time TEXT DEFAULT '00:00',
                averaging_enabled INTEGER DEFAULT 0,
                averaging_pause REAL DEFAULT 300.0
            )
        ''')
        
        # Создание таблицы trades
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trades
            (
                trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                symbol TEXT,
                side TEXT,
                price REAL,
                amount REAL,
                timestamp INTEGER,
                status TEXT,
                timescale TEXT,
                current_stop_price REAL,
                open_order_id TEXT,
                close_order_id TEXT,
                average_entry_price REAL,
                trailing_active INTEGER DEFAULT 0,
                highest_price REAL,
                lowest_price REAL,
                close_reason TEXT,
                close_price REAL,
                pnl REAL DEFAULT 0.0,
                fees REAL DEFAULT 0.0,
                original_stop_price REAL,
                trailing_stop_price REAL,
                margin REAL,
                balance_at_open REAL,
                signal_id TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Создание таблицы tp_config
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tp_config
            (
                user_id INTEGER,
                timescale TEXT NOT NULL,
                stop_loss_percentage REAL,
                trigger_profit_percentage REAL,
                trailing_percentage REAL,
                profit_lock_percentage REAL,
                pnl_based_trailing BOOLEAN DEFAULT 0,
                PRIMARY KEY (user_id, timescale)
            )
        ''')
        
        # Добавляем пользователя по умолчанию, если таблица пуста
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO users (user_id) VALUES (0)")
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Ошибка создания базы данных: {e}")
        return False

def check_required_files():
    """Проверка наличия необходимых файлов"""
    required_files = ["traiding_bot.py", "advanced_trading_backtester_multithread_ultrafast.py"]
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print("⚠️  Внимание: Некоторые файлы отсутствуют:")
        for file in missing_files:
            print(f"   - {file}")
        print()
        return False
    else:
        print("✅ Все необходимые файлы найдены")
        print()
        return True

def show_menu():
    """Отображение меню"""
    print("\nПожалуйста, выберите действие:")
    print("1. 🤖 Запустить торговый бот")
    print("2. 📊 Запустить бэктест")
    print("3. 📥 Импортировать оптимальные настройки")
    print("4. ⚙️  Сброс к заводским настройкам")
    print("0. ❌ Выход")

def run_trading_bot():
    """Запуск торгового бота"""
    print("\nЗапуск торгового бота...")
    time.sleep(1)
    
    # Проверяем наличие файла торгового бота
    bot_file = "traiding_bot.py"
    if os.path.exists(bot_file):
        try:
            subprocess.run([sys.executable, bot_file], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Ошибка при запуске торгового бота: {e}")
        except KeyboardInterrupt:
            print("\nТорговый бот остановлен пользователем")
    else:
        print(f"Файл {bot_file} не найден!")

def run_backtest():
    """Запуск бэктеста"""
    print("\nЗапуск бэктеста...")
    time.sleep(1)
    
    # Запуск оригинального бэктеста через clear_cache_and_run.bat
    backtest_file = "clear_cache_and_run.bat"
    if os.path.exists(backtest_file):
        try:
            subprocess.run([backtest_file], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            print(f"Ошибка при запуске бэктеста: {e}")
        except KeyboardInterrupt:
            print("\nБэктест остановлен пользователем")
    else:
        print(f"Файл {backtest_file} не найден!")

def import_optimal_settings():
    """Импорт оптимальных настроек из JSON файла в trading_bot.db"""
    print("\nИмпорт оптимальных настроек...")
    
    # Поиск файлов с оптимальными настройками
    json_files = [f for f in os.listdir('.') if f.startswith('best_settings_all_') and f.endswith('.json')]
    
    if not json_files:
        print("❌ Файлы с оптимальными настройками не найдены!")
        return
    
    # Сортируем файлы по дате (новые первыми)
    json_files.sort(reverse=True)
    
    print(f"\nНайдено {len(json_files)} файлов с оптимальными настройками:")
    for i, file in enumerate(json_files, 1):
        print(f"{i}. {file}")
    
    try:
        choice = input(f"\nВыберите файл (1-{len(json_files)}) или 0 для отмены: ").strip()
        if choice == "0":
            print("Отмена импорта.")
            return
        
        file_index = int(choice) - 1
        if file_index < 0 or file_index >= len(json_files):
            print("Неверный выбор!")
            return
            
        selected_file = json_files[file_index]
        print(f"\nИмпорт настроек из {selected_file}...")
        
        # Читаем JSON файл
        with open(selected_file, 'r', encoding='utf-8') as f:
            settings_data = json.load(f)
        
        # Подключаемся к базе данных
        conn = sqlite3.connect('trading_bot.db')
        cursor = conn.cursor()
        
        # Импортируем настройки для каждого таймфрейма
        imported_count = 0
        for timeframe, config in settings_data.get('settings', {}).items():
            params = config.get('params', {})
            
            # Вставляем или обновляем настройки в таблице tp_config
            cursor.execute('''
                INSERT OR REPLACE INTO tp_config 
                (user_id, timescale, stop_loss_percentage, trigger_profit_percentage, 
                 trailing_percentage, profit_lock_percentage)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                0,  # user_id = 0 для общих настроек
                timeframe,
                params.get('stop_loss_percentage', 3.0),
                params.get('trigger_profit_percentage', 5.0),
                params.get('trailing_percentage', 1.0),
                params.get('profit_lock_percentage', 2.0)
            ))
            imported_count += 1
        
        conn.commit()
        conn.close()
        
        print(f"✅ Успешно импортировано настройки для {imported_count} таймфреймов из файла {selected_file}")
        
    except Exception as e:
        print(f"❌ Ошибка при импорте настроек: {e}")

def collect_custom_strategy_settings():
    """Сбор настроек для пользовательской стратегии"""
    print("\n=== Настройка пользовательской стратегии ===")
    
    custom_settings = {}
    
    # 1. Тип счёта (выбор из вариантов)
    print("\nТип счёта:")
    print("1. Реальный")
    print("2. Демо")
    print("0. Вернуться в главное меню")
    
    account_type = None
    while True:
        try:
            choice = input("\nВыберите тип счёта (0-2): ").strip()
            if choice == "0":
                return None  # Возврат в главное меню
            elif choice == "1":
                account_type = 'real'
                custom_settings['account_type'] = 'real'
                break
            elif choice == "2":
                account_type = 'demo'
                custom_settings['account_type'] = 'demo'
                break
            else:
                print("Пожалуйста, введите число от 0 до 2.")
        except ValueError:
            print("Пожалуйста, введите число от 0 до 2.")
    
    # 2. API ключи Gate.io (запрашиваются для обоих типов счетов)
    print(f"\nВведите API ключи Gate.io для {('реального' if account_type == 'real' else 'демо')} счета:")
    while True:
        api_key = input("API Key: ").strip()
        if api_key:
            break
        else:
            print("API Key не может быть пустым.")
    
    while True:
        api_secret = input("API Secret: ").strip()
        if api_secret:
            break
        else:
            print("API Secret не может быть пустым.")
    
    # Проверяем валидность API ключей с учетом типа счета
    print("\nПроверка API ключей...")
    if not validate_api_keys(api_key, api_secret, account_type):
        print("❌ Введенные API ключи недействительны!")
        return None
    
    custom_settings['api_key'] = api_key
    custom_settings['api_secret'] = api_secret
    
    # 3. Плечо (ввод числа)
    while True:
        try:
            leverage = input("\nВведите кредитное плечо (по умолчанию 10): ").strip()
            if leverage == "":
                leverage = "10"
            leverage = float(leverage)
            if leverage > 0:
                custom_settings['leverage'] = leverage
                break
            else:
                print("Плечо должно быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 4. Режим маржи (выбор из вариантов)
    print("\nРежим маржи:")
    print("1. Изолированная (isolated)")
    print("2. Перекрёстная (cross)")
    print("0. Вернуться в главное меню")
    
    while True:
        try:
            choice = input("\nВыберите режим маржи (0-2): ").strip()
            if choice == "0":
                return None  # Возврат в главное меню
            elif choice == "1":
                custom_settings['margin_mode'] = 'isolated'
                break
            elif choice == "2":
                custom_settings['margin_mode'] = 'cross'
                break
            else:
                print("Пожалуйста, введите число от 0 до 2.")
        except ValueError:
            print("Пожалуйста, введите число от 0 до 2.")
    
    # 5. Тип ордера (выбор из вариантов)
    print("\nТип ордера:")
    print("1. Процент от баланса (percentage)")
    print("2. Фиксированный объем (fixed)")
    print("0. Вернуться в главное меню")
    
    while True:
        try:
            choice = input("\nВыберите тип ордера (0-2): ").strip()
            if choice == "0":
                return None  # Возврат в главное меню
            elif choice == "1":
                custom_settings['order_type'] = 'percentage'
                break
            elif choice == "2":
                custom_settings['order_type'] = 'fixed'
                break
            else:
                print("Пожалуйста, введите число от 0 до 2.")
        except ValueError:
            print("Пожалуйста, введите число от 0 до 2.")
    
    # 6. Процент от баланса / фиксированный объем (ввод числа)
    if custom_settings['order_type'] == 'percentage':
        while True:
            try:
                qty_percentage = input("\nВведите процент от баланса (по умолчанию 5): ").strip()
                if qty_percentage == "":
                    qty_percentage = "5"
                qty_percentage = float(qty_percentage)
                if qty_percentage > 0:
                    custom_settings['qty_percentage'] = qty_percentage
                    break
                else:
                    print("Процент должен быть положительным числом.")
            except ValueError:
                print("Пожалуйста, введите число.")
    else:
        while True:
            try:
                fixed_volume = input("\nВведите фиксированный объем (USDT, по умолчанию 100): ").strip()
                if fixed_volume == "":
                    fixed_volume = "100"
                fixed_volume = float(fixed_volume)
                if fixed_volume > 0:
                    custom_settings['fixed_volume'] = fixed_volume
                    break
                else:
                    print("Объем должен быть положительным числом.")
            except ValueError:
                print("Пожалуйста, введите число.")
    
    # 7. Стоп-лосс (ввод числа)
    while True:
        try:
            stop_loss = input("\nВведите стоп-лосс (%) (по умолчанию 3): ").strip()
            if stop_loss == "":
                stop_loss = "3"
            stop_loss = float(stop_loss)
            if stop_loss > 0:
                custom_settings['initial_stop_percentage'] = stop_loss
                break
            else:
                print("Стоп-лосс должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 8. Триггер трейлинга (ввод числа)
    while True:
        try:
            trigger_profit = input("\nВведите триггер трейлинга (%) (по умолчанию 5): ").strip()
            if trigger_profit == "":
                trigger_profit = "5"
            trigger_profit = float(trigger_profit)
            if trigger_profit > 0:
                custom_settings['trigger_profit_percentage'] = trigger_profit
                break
            else:
                print("Триггер трейлинга должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 9. Фиксация прибыли (ввод числа)
    while True:
        try:
            profit_lock = input("\nВведите фиксацию прибыли (%) (по умолчанию 2): ").strip()
            if profit_lock == "":
                profit_lock = "2"
            profit_lock = float(profit_lock)
            if profit_lock > 0:
                custom_settings['profit_lock_percentage'] = profit_lock
                break
            else:
                print("Фиксация прибыли должна быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 10. Трейлинг-стоп (ввод числа)
    while True:
        try:
            trailing = input("\nВведите трейлинг-стоп (%) (по умолчанию 1): ").strip()
            if trailing == "":
                trailing = "1"
            trailing = float(trailing)
            if trailing > 0:
                custom_settings['trailing_percentage'] = trailing
                break
            else:
                print("Трейлинг-стоп должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 11. Интервал трейлинга (ввод числа)
    while True:
        try:
            trailing_interval = input("\nВведите интервал трейлинга (секунды, по умолчанию 3): ").strip()
            if trailing_interval == "":
                trailing_interval = "3"
            trailing_interval = float(trailing_interval)
            if trailing_interval > 0:
                custom_settings['trailing_interval'] = trailing_interval
                break
            else:
                print("Интервал трейлинга должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    # 12. Лимит убыточных сделок (ввод числа)
    while True:
        try:
            daily_loss_limit = input("\nВведите лимит убыточных сделок в день (по умолчанию 3): ").strip()
            if daily_loss_limit == "":
                daily_loss_limit = "3"
            daily_loss_limit = int(daily_loss_limit)
            if daily_loss_limit > 0:
                custom_settings['daily_loss_limit'] = daily_loss_limit
                break
            else:
                print("Лимит должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите целое число.")
    
    # 13. Максимум открытых позиций (ввод числа)
    while True:
        try:
            max_open_trades = input("\nВведите максимум открытых позиций (по умолчанию 5): ").strip()
            if max_open_trades == "":
                max_open_trades = "5"
            max_open_trades = int(max_open_trades)
            if max_open_trades > 0:
                custom_settings['max_open_trades'] = max_open_trades
                break
            else:
                print("Максимум должен быть положительным числом.")
        except ValueError:
            print("Пожалуйста, введите целое число.")
    
    return custom_settings

def reset_to_factory_settings():
    """Сброс к заводским настройкам"""
    print("\nСброс к заводским настройкам...")
    
    # Подтверждение сброса
    print("\n⚠️  ВНИМАНИЕ: Это действие удалит все текущие настройки!")
    print("Вы уверены, что хотите сбросить все настройки к заводским?")
    print("1. Да, сбросить все настройки")
    print("2. Нет, вернуться в главное меню")
    
    while True:
        try:
            confirm = input("\nВыберите действие (1-2): ").strip()
            if confirm == "1":
                break
            elif confirm == "2":
                print("Сброс отменен. Возврат в главное меню")
                return
            else:
                print("Пожалуйста, введите 1 или 2.")
        except ValueError:
            print("Пожалуйста, введите 1 или 2.")
    
    # Подключаемся к базе данных
    conn = sqlite3.connect('trading_bot.db')
    cursor = conn.cursor()
    
    try:
        # Очищаем таблицу tp_config
        cursor.execute("DELETE FROM tp_config")
        print("Очищена таблица конфигураций тейк-профитов")
        
        # Сбрасываем настройки пользователей к значениям по умолчанию
        cursor.execute('''
            UPDATE users SET
                api_key = NULL,
                api_secret = NULL,
                account_type = 'demo',
                leverage = 10.0,
                margin_mode = 'isolated',
                order_type = 'percentage',
                qty_percentage = 5.0,
                fixed_volume = 100.0,
                initial_stop_percentage = 3.0,
                trigger_profit_percentage = 5.0,
                profit_lock_percentage = 2.0,
                trailing_percentage = 1.0,
                trailing_interval = 3.0,
                daily_loss_limit = 3,
                max_open_trades = 5,
                is_trading = 0,
                report_type = 'fixed',
                report_time = '00:00',
                averaging_enabled = 0,
                averaging_pause = 300.0
        ''')
        print("Сброшены настройки пользователей к значениям по умолчанию")
        
        conn.commit()
        print("✅ Сброс к заводским настройкам завершен")
        
        # Предлагаем выбрать стратегию
        print("\nПожалуйста, выберите стратегию:")
        print("0. Вернуться в главное меню")
        print("1. 🚀 Разгон депозита — агрессивно, быстрый рост и большие риски")
        print("2. ⚡ Скальпинг — частые короткие сделки, быстрые входы/выходы")
        print("3. 🛡 Уверенная торговля — минимальные риски, долгосрочный рост")
        print("4. 🧩 Своя стратегия — вы сами задаёте все параметры")
        
        choice = input("\nВведите номер стратегии (0-4): ").strip()
        
        if choice == "0":
            print("Возврат в главное меню")
            return
        elif choice in ["1", "2", "3"]:
            strategy_templates = {
                '1': {  # Разгон депозита
                    'leverage': 20, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
                    'initial_stop_percentage': 5.0, 'trigger_profit_percentage': 10.0, 'profit_lock_percentage': 3.5,
                    'trailing_percentage': 2.0, 'trailing_interval': 2, 'daily_loss_limit': 10, 'max_open_trades': 10
                },
                '2': {  # Скальпинг
                    'leverage': 15, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
                    'initial_stop_percentage': 4.0, 'trigger_profit_percentage': 6.0, 'profit_lock_percentage': 2.5,
                    'trailing_percentage': 1.5, 'trailing_interval': 2, 'daily_loss_limit': 5, 'max_open_trades': 5
                },
                '3': {  # Уверенная торговля
                    'leverage': 10, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
                    'initial_stop_percentage': 3.5, 'trigger_profit_percentage': 5.0, 'profit_lock_percentage': 2.0,
                    'trailing_percentage': 1.2, 'trailing_interval': 3, 'daily_loss_limit': 2, 'max_open_trades': 2
                }
            }
            
            template = strategy_templates[choice]
            strategy_names = {'1': 'разгон', '2': 'скальпинг', '3': 'уверенная'}
            strategy_name = strategy_names[choice]
            
            # Применяем шаблон настроек
            cursor.execute('''
                UPDATE users SET
                    leverage = ?,
                    margin_mode = ?,
                    order_type = ?,
                    qty_percentage = ?,
                    initial_stop_percentage = ?,
                    trigger_profit_percentage = ?,
                    profit_lock_percentage = ?,
                    trailing_percentage = ?,
                    trailing_interval = ?,
                    daily_loss_limit = ?,
                    max_open_trades = ?
            ''', (
                template['leverage'],
                template['margin_mode'],
                template['order_type'],
                template['qty_percentage'],
                template['initial_stop_percentage'],
                template['trigger_profit_percentage'],
                template['profit_lock_percentage'],
                template['trailing_percentage'],
                template['trailing_interval'],
                template['daily_loss_limit'],
                template['max_open_trades']
            ))
            
            conn.commit()
            print(f"✅ Применена стратегия '{strategy_name}'")
            
        elif choice == "4":
            print("Выбрана своя стратегия. Запуск интерактивной настройки...")
            custom_settings = collect_custom_strategy_settings()
            
            # Если пользователь выбрал возврат в главное меню
            if custom_settings is None:
                print("Возврат в главное меню")
                return
            
            # Применяем пользовательские настройки
            cursor.execute('''
                UPDATE users SET
                    api_key = ?,
                    api_secret = ?,
                    account_type = ?,
                    leverage = ?,
                    margin_mode = ?,
                    order_type = ?,
                    qty_percentage = ?,
                    fixed_volume = ?,
                    initial_stop_percentage = ?,
                    trigger_profit_percentage = ?,
                    profit_lock_percentage = ?,
                    trailing_percentage = ?,
                    trailing_interval = ?,
                    daily_loss_limit = ?,
                    max_open_trades = ?
            ''', (
                custom_settings.get('api_key'),
                custom_settings.get('api_secret'),
                custom_settings.get('account_type', 'demo'),
                custom_settings.get('leverage', 10.0),
                custom_settings.get('margin_mode', 'isolated'),
                custom_settings.get('order_type', 'percentage'),
                custom_settings.get('qty_percentage', 5.0),
                custom_settings.get('fixed_volume', 100.0),
                custom_settings.get('initial_stop_percentage', 3.0),
                custom_settings.get('trigger_profit_percentage', 5.0),
                custom_settings.get('profit_lock_percentage', 2.0),
                custom_settings.get('trailing_percentage', 1.0),
                custom_settings.get('trailing_interval', 3.0),
                custom_settings.get('daily_loss_limit', 3),
                custom_settings.get('max_open_trades', 5)
            ))
            
            conn.commit()
            print("✅ Применены пользовательские настройки")
            
        else:
            print("Неверный выбор. Настройки сброшены к значениям по умолчанию.")
            
    except Exception as e:
        print(f"❌ Ошибка при сбросе настроек: {e}")
    finally:
        conn.close()

def main():
    """Главная функция"""
    # Проверка и создание базы данных при необходимости
    if not os.path.exists('trading_bot.db'):
        print("Создание базы данных...")
        if not setup_database():
            print("❌ Не удалось создать базу данных!")
            return
    
    while True:
        print_header()
        
        # Проверка базы данных и API ключей
        if not check_database():
            print("\n⚠️  Необходимо настроить API ключи и стратегию!")
            print("Запуск процесса регистрации...")
            time.sleep(2)
            
            # Подключаемся к базе данных
            conn = sqlite3.connect('trading_bot.db')
            cursor = conn.cursor()
            
            # Сбрасываем настройки пользователей к значениям по умолчанию
            cursor.execute('''
                UPDATE users SET
                    api_key = NULL,
                    api_secret = NULL,
                    account_type = 'demo',
                    leverage = 10.0,
                    margin_mode = 'isolated',
                    order_type = 'percentage',
                    qty_percentage = 5.0,
                    fixed_volume = 100.0,
                    initial_stop_percentage = 3.0,
                    trigger_profit_percentage = 5.0,
                    profit_lock_percentage = 2.0,
                    trailing_percentage = 1.0,
                    trailing_interval = 3.0,
                    daily_loss_limit = 3,
                    max_open_trades = 5,
                    is_trading = 0,
                    report_type = 'fixed',
                    report_time = '00:00',
                    averaging_enabled = 0,
                    averaging_pause = 300.0
            ''')
            conn.commit()
            conn.close()
            
            # Запускаем настройку пользовательской стратегии
            custom_settings = collect_custom_strategy_settings()
            
            if custom_settings is None:
                print("Регистрация отменена.")
                input("\nНажмите Enter для продолжения...")
                continue
            
            # Сохраняем настройки
            conn = sqlite3.connect('trading_bot.db')
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users SET
                    api_key = ?,
                    api_secret = ?,
                    account_type = ?,
                    leverage = ?,
                    margin_mode = ?,
                    order_type = ?,
                    qty_percentage = ?,
                    fixed_volume = ?,
                    initial_stop_percentage = ?,
                    trigger_profit_percentage = ?,
                    profit_lock_percentage = ?,
                    trailing_percentage = ?,
                    trailing_interval = ?,
                    daily_loss_limit = ?,
                    max_open_trades = ?
            ''', (
                custom_settings.get('api_key'),
                custom_settings.get('api_secret'),
                custom_settings.get('account_type', 'demo'),
                custom_settings.get('leverage', 10.0),
                custom_settings.get('margin_mode', 'isolated'),
                custom_settings.get('order_type', 'percentage'),
                custom_settings.get('qty_percentage', 5.0),
                custom_settings.get('fixed_volume', 100.0),
                custom_settings.get('initial_stop_percentage', 3.0),
                custom_settings.get('trigger_profit_percentage', 5.0),
                custom_settings.get('profit_lock_percentage', 2.0),
                custom_settings.get('trailing_percentage', 1.0),
                custom_settings.get('trailing_interval', 3.0),
                custom_settings.get('daily_loss_limit', 3),
                custom_settings.get('max_open_trades', 5)
            ))
            conn.commit()
            conn.close()
            
            print("✅ Регистрация завершена успешно!")
            input("\nНажмите Enter для продолжения...")
            continue
        
        # Проверка наличия необходимых файлов
        check_required_files()
        
        show_menu()
        
        try:
            choice = input("\nВведите номер действия (0-4): ").strip()
            
            if choice == "0":
                print("\nСпасибо за использование! До свидания!")
                time.sleep(1)
                break
            elif choice == "1":
                run_trading_bot()
                input("\nНажмите Enter для возврата в меню...")
            elif choice == "2":
                run_backtest()
                input("\nНажмите Enter для возврата в меню...")
            elif choice == "3":
                import_optimal_settings()
                input("\nНажмите Enter для возврата в меню...")
            elif choice == "4":
                reset_to_factory_settings()
                input("\nНажмите Enter для возврата в меню...")
            else:
                print("\nНеверный выбор! Пожалуйста, введите число от 0 до 4.")
                time.sleep(2)
                
        except KeyboardInterrupt:
            print("\n\nПрограмма прервана пользователем. До свидания!")
            break
        except Exception as e:
            print(f"\nПроизошла непредвиденная ошибка: {e}")
            time.sleep(2)

if __name__ == "__main__":
    main()